package StepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class AccountstepDefs {
    @Given("the valid date of birth and username and email")
    public void theValidDateOfBirthAndUsernameAndEmail() {
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://membership.basketballengland.co.uk/NewSupporterAccount");
        driver.findElement(By.id("dp")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[2]")));
        String actualMonthandYear = driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[2]")).getText();
        while (!(actualMonthandYear.equals("April 2001"))) {

            driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[1]")).click();
            actualMonthandYear = driver.findElement(By.className("datepicker-switch")).getText();

        }
        driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/tbody/tr[3]/td[5]")).click();

        WebElement username = driver.findElement(By.xpath("/html/body/div/div[2]/div/div/div/div/div/div/div/form/div[5]/div[1]/div/input"));

        username.click();
        username.sendKeys("Vamsi");
    }

    @When("i enter password and check on required boxes")
    public void iEnterPasswordAndCheckOnRequiredBoxes() {
    }

    @Then("the accound is created")
    public void theAccoundIsCreated() {
    }
}
