package StepDef;

import Common.Calculator;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static org.junit.Assert.assertEquals;
public class Defs1 {
    private WebDriver driver;

    @Given("i navigate to webpage and enter date of birth")
    public void iNavigateToWebpageAndEnterDateOfBirth() {

        WebDriver driver = new ChromeDriver();
        driver.get("https://membership.basketballengland.co.uk/NewSupporterAccount");
        driver.findElement(By.id("dp")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[2]")));
        String actualMonthandYear = driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[2]")).getText();
        while (!(actualMonthandYear.equals("April 2001"))) {

            driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/thead/tr[2]/th[1]")).click();
            actualMonthandYear = driver.findElement(By.className("datepicker-switch")).getText();

        }
        driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/tbody/tr[3]/td[5]")).click();

    }

    @And("i enter firstname and lastname and email")

    public void iEnterFirstnameAndLastnameAndEmail() {

WebElement username = driver.findElement(By.xpath("/html/body/div/div[2]/div/div/div/div/div/div/div/form/div[5]/div[1]/div/input"));

     username.click();
    username.sendKeys("Vamsi");
            
    }


    @When("i enter password and retype password")
    public void iEnterPasswordAndRetypePassword() {


    }

    @And("i select the role in basketball and confirm the account i click on Communication preferences and code of ethics and click on create account")
    public void iSelectTheRoleInBasketballAndConfirmTheAccountIClickOnCommunicationPreferencesAndCodeOfEthicsAndClickOnCreateAccount() {

    }

    @Then("i should be able to succesfully create account")
    public void iShouldBeAbleToSuccesfullyCreateAccount() {
    }
}
