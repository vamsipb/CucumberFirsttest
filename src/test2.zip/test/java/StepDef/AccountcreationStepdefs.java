package StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AccountcreationStepdefs {
    private WebDriver driver;

    @Given("i enter date")
    public void i_enter_date() {
        driver = new ChromeDriver();

        driver.get("https://membership.basketballengland.co.uk/NewSupporterAccount");
        WebElement date = driver.findElement(By.id("dp"));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        date.click();
        date.sendKeys("15-04-1993");

        throw new io.cucumber.java.PendingException();
    }

    @And("i enter firstname {string}")
    public void i_enter_firstname(String string) {
        WebElement Firstname = driver.findElement(By.xpath("/html/body/div/div[2]/div/div/div/div/div/div/div/form/div[5]/div[1]/div/input"));
        Firstname.sendKeys("veda");

        throw new io.cucumber.java.PendingException();
    }

    @And("i enter the lastname {string}")
    public void i_enter_the_lastname(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @And("i enter email {string}")
    public void i_enter_email(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @And("i re-enter email {string}")
    public void i_re_enter_email(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @And("i enter password {string}")
    public void i_enter_password(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @And("i re-enter password {string}")
    public void i_re_enter_password(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @And("i check on the important buttons")
    public void i_check_on_the_important_buttons() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @When("i click on create account button")
    public void i_click_on_create_account_button() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("the account is succefully created")
    public void the_account_is_succefully_created() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
}